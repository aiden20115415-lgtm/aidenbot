import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

let toggleImage = true;

export default {
    name: 'اوامر',
    aliases: ['menu', 'القائمة', 'المهام'],
    description: 'عرض قائمة أوامر البوت المتاحة',
    execute: async (sock, m, args, { cmds, cfg }) => {
        try {
            const senderJid = m.key.participant || m.participant || m.key.remoteJid;
            const chatJid = m.key.remoteJid;

            await sock.sendMessage(chatJid, { react: { text: '🌹', key: m.key } });

            const pathZarf = path.join(__dirname, '../zarf.png');
            const pathMenu = path.join(__dirname, '../menu.png');
            
            const selectedPath = toggleImage ? pathZarf : pathMenu;
            toggleImage = !toggleImage;

            let imageBuffer;
            if (fs.existsSync(selectedPath)) {
                imageBuffer = fs.readFileSync(selectedPath);
            } else {
                imageBuffer = { url: 'https://files.catbox.moe/1xmxho.png' };
            }

            const uptime = process.uptime();
            const uptimeStr = `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m`;

            const menuText = `> ━ ╼╃ ⌬〔 ~𝐋𝐈𝐋𝐈𝐓𝐇 𝐁𝐎𝐓~ 〕⌬ ╄╾ ━
> *┤────────────···*
> *┤ أهلاً بكِ @${senderJid.split('@')[0]} 🌹*
> *┤────────────···*
> *✧──[ معلومات الـب -وت ]──╮*
> *┤ 🌹 ┊الإسم: 🌹 LILITH-BOT*
> *┤ 🍁 ┊النشاط: ${uptimeStr}*
> *⋅ ───━ •﹝🌹 ﹞• ━─── ⋅*
\`🐝 𝐋𝐈𝐋𝐈𝐘 - 𝐋𝐈𝐋𝐈𝐓𝐇 𝐁𝐎𝐓 🍯\``;

            const media = await prepareWAMessageMedia(
                { image: imageBuffer }, 
                { upload: sock.waUploadToServer }
            );

            const commandRows = Array.from(cmds.values()).map(cmd => ({
                title: `${cfg.prefix}${cmd.name}`,
                id: `${cfg.prefix}${cmd.name}`,
                description: cmd.description || 'لا يوجد وصف'
            }));

            const msg = generateWAMessageFromContent(chatJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: menuText },
                            footer: { text: cfg.botRights || 'Lilith Bot' },
                            header: {
                                hasMediaAttachment: true,
                                imageMessage: media.imageMessage
                            },
                            contextInfo: {
                                mentionedJid: [senderJid],
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: "120363291138572523@newsletter",
                                    serverMessageId: '',
                                    newsletterName: '𝐋𝐈𝐋𝐈𝐓𝐇 ꒰🐝⃝⃕꒱ 𝐁𝐎𝐓'
                                }
                            },
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "single_select",
                                        buttonParamsJson: JSON.stringify({
                                            title: '📜┇الـقـائمة┇📜',
                                            sections: [{
                                                title: '📂 ┇ الأوامر المتوفرة ┇ 📂',
                                                rows: commandRows
                                            }]
                                        })
                                    }
                                ]
                            }
                        }
                    }
                }
            }, { userJid: chatJid, quoted: m });

            await sock.relayMessage(chatJid, msg.message, { messageId: msg.key.id });

        } catch (e) {
            console.error(e);
            await sock.sendMessage(m.key.remoteJid, { text: '❌ حدث خطأ أثناء تشغيل القائمة.' }, { quoted: m });
        }
    }
};