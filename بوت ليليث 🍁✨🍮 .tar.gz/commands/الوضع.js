import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const configPath = path.join(__dirname, '../config.js');

export default {
    name: 'الوضع',
    aliases: ['مود', 'وضع'],
    description: 'تغيير وضع البوت بنظام ذكي',

    execute: async (sock, m, args, { cfg, command }) => {
        const getPureId = (jid) => jid ? jid.split('@')[0].split(':')[0].replace(/[^0-9a-zA-Z]/g, '') : '';
        const senderPure = getPureId(m.key.participant || m.participant || m.key.remoteJid);

        const smartEliteSet = new Set([cfg.ownerNumber, ...(cfg.eliteNumbers || [])].map(num => getPureId(num)));
        const isOwner = senderPure === getPureId(cfg.ownerNumber);
        const isElite = smartEliteSet.has(senderPure);

        if (!isOwner && !isElite) {
            return sock.sendMessage(m.key.remoteJid, {
                text: cfg.msgs.elite(command.name)
            }, { quoted: m });
        }

        const input = args[0]?.toLowerCase();
        let newMode = '';

        if (input === 'عام' || input === 'public') {
            newMode = 'Public';
        } else if (input === 'خاص' || input === 'private') {
            newMode = 'Private';
        } else {
            return sock.sendMessage(m.key.remoteJid, {
                text: `⟡ استخدم: ${cfg.prefix}الوضع عام / خاص`
            }, { quoted: m });
        }

        try {
            await sock.sendMessage(m.key.remoteJid, {
                react: { text: '🐝', key: m.key }
            });

            let configContent = fs.readFileSync(configPath, 'utf8');
            configContent = configContent.replace(
                /mode:\s*['"][^'"]*['"]/,
                `mode: '${newMode}'`
            );

            fs.writeFileSync(configPath, configContent);
            cfg.mode = newMode;

            const ui = newMode === 'Public'
                ? `╭───〔 🟢 PUBLIC MODE 〕───╮\n│ البوت مفتوح للجميع\n╰──────────────────────╯`
                : `╭───〔 🔴 PRIVATE MODE 〕───╮\n│ البوت خاص للمطور والنخبة\n╰──────────────────────╯`;

            await sock.sendMessage(m.key.remoteJid, { text: ui }, { quoted: m });

        } catch (e) {
            console.error(e);
            sock.sendMessage(m.key.remoteJid, { text: 'error' });
        }
    }
};