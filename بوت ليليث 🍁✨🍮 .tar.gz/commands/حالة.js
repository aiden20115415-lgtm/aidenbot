import os from 'os';

export default {
    name: 'حالة',
    aliases: ['تست', 'ping', 'status'],
    description: 'حالة البوت',

    execute: async (sock, m, args, { cfg }) => {
        try {

            await sock.sendMessage(m.key.remoteJid, {
                react: { text: '⚡', key: m.key }
            });

            const start = Date.now();

            const { key } = await sock.sendMessage(
                m.key.remoteJid,
                { text: '...' }
            );

            const ping = Date.now() - start;

            const uptime = process.uptime();
            const h = Math.floor(uptime / 3600);
            const mnt = Math.floor((uptime % 3600) / 60);
            const s = Math.floor(uptime % 60);

            const total = (os.totalmem() / 1e9).toFixed(1);
            const free = (os.freemem() / 1e9).toFixed(1);
            const used = (total - free).toFixed(1);

            await sock.sendMessage(m.key.remoteJid, {
                text: `Lilith-bot : Hi 🐝 | ${ping}ms`,
                edit: key
            });

        } catch (e) {
            await sock.sendMessage(m.key.remoteJid, {
                text: `Lilith-bot : error 🐝`
            });
        }
    }
};