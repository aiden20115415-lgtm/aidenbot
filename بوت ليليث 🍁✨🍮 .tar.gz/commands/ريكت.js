import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const reactPath = path.join(__dirname, '../react.json');

if (!fs.existsSync(reactPath)) {
    fs.writeFileSync(reactPath, JSON.stringify({ enabled: false }, null, 2));
}

const reactions = ['✨', '🐝', '🐊', '🍮', '🍯'];
let handlerInitialized = false;

export default {
    name: 'ريكت',
    aliases: [],
    hidden: true,
    description: 'Elite Auto React',
    execute: async (sock, m, args, { cfg, command }) => {
        try {
            const getPureId = (jid) => jid ? jid.split('@')[0].split(':')[0].replace(/[^0-9a-zA-Z]/g, '') : '';
            const senderPure = getPureId(m.key.participant || m.participant || m.key.remoteJid);

            const smartEliteSet = new Set([cfg.ownerNumber, ...(cfg.eliteNumbers || [])].map(num => getPureId(num)));
            const isOwner = senderPure === getPureId(cfg.ownerNumber);
            const isElite = smartEliteSet.has(senderPure);

            if (!isOwner && !isElite) {
                return sock.sendMessage(m.key.remoteJid, { text: cfg.msgs.elite(command.name) }, { quoted: m });
            }

            const data = JSON.parse(fs.readFileSync(reactPath));
            const input = args[0]?.toLowerCase();

            if (input === 'تشغيل' || input === 'on') {
                data.enabled = true;
                fs.writeFileSync(reactPath, JSON.stringify(data, null, 2));
                await sock.sendMessage(m.key.remoteJid, { text: `╭━━━〔 🐝 REACT SYSTEM 🐝 〕━━━╮\n┃ ✅ تم تشغيل الريكت\n┃ ⚡ Elite React : ON\n╰━━━━━━━━━━━━━━━━━━━━╯` }, { quoted: m });
            }
            else if (input === 'إيقاف' || input === 'ايقاف' || input === 'off') {
                data.enabled = false;
                fs.writeFileSync(reactPath, JSON.stringify(data, null, 2));
                await sock.sendMessage(m.key.remoteJid, { text: `╭━━━〔 🐝 REACT SYSTEM 🐝 〕━━━╮\n┃ ❌ تم إيقاف الريكت\n┃ ⚡ Elite React : OFF\n╰━━━━━━━━━━━━━━━━━━━━╯` }, { quoted: m });
            }
            else {
                return sock.sendMessage(m.key.remoteJid, { text: `.ريكت تشغيل\n.ريكت إيقاف` }, { quoted: m });
            }

            if (!handlerInitialized) {
                handlerInitialized = true;
                sock.ev.on('messages.upsert', async ({ messages }) => {
                    try {
                        const msg = messages[0];
                        if (!msg?.message || !msg?.key || msg.key.fromMe) return;

                        const current = JSON.parse(fs.readFileSync(reactPath));
                        if (!current.enabled) return;

                        const msgSenderPure = getPureId(msg.key.participant || msg.participant || msg.key.remoteJid);
                        
                        // تحديث قائمة النخبة لحظياً للتأكد من أي تغييرات في config
                        const eliteCheck = new Set([cfg.ownerNumber, ...(cfg.eliteNumbers || [])].map(num => getPureId(num)));

                        if (eliteCheck.has(msgSenderPure)) {
                            const emoji = reactions[Math.floor(Math.random() * reactions.length)];
                            await sock.sendMessage(msg.key.remoteJid, { react: { text: emoji, key: msg.key } });
                        }
                    } catch {}
                });
            }
        } catch (e) {
            console.log(`╭━━━〔 ❌ REACT ERROR ❌ 〕━━━╮\n┃ ⚠️ ${e.message}\n╰━━━━━━━━━━━━━━━━━━━━╯`);
        }
    }
};