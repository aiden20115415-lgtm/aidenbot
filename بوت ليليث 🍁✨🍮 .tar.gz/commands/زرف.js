// ────────────────〔 🐝 LILITH ZARF SYSTEM 🐝 〕────────────────

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(
    fileURLToPath(import.meta.url)
);

export default {

    name: 'زرف',
    aliases: ['تزريف'],

    description: '🐝 زرف إداري ذكي للنخبة',

    execute: async (
        sock,
        m,
        args,
        { cfg, command }
    ) => {

        const chatJid = m.key.remoteJid;

        // دالة التنقية القصوى: تأخذ فقط الأرقام أو الحروف البرمجية قبل الـ @ والـ :
        const getPureId = (jid) => {
            if (!jid) return '';
            return jid.split('@')[0].split(':')[0].replace(/[^0-9a-zA-Z]/g, '');
        };

        try {
            // 1️⃣ استخراج كافة أرقام النخبة والمطور من الإعدادات
            const rawElite = [cfg.ownerNumber, ...(cfg.eliteNumbers || [])];
            
            // 2️⃣ إنشاء قائمة "النخبة الذكية" (تخزن المعرفات النقية فقط)
            const smartEliteSet = new Set();

            console.log('🔍 [ZARF DEBUG] جاري فحص وتحويل أرقام النخبة...');

            // معالجة الأرقام وتحويلها لـ LID و JID في الخلفية لضمان السرعة
            await Promise.all(rawElite.map(async (input) => {
                const pure = input.toString().replace(/[^0-9]/g, '');
                if (!pure) return;

                // إضافة الرقم العادي
                smartEliteSet.add(pure);

                try {
                    // محاولة جلب الـ LID من واتساب (نفس أسلوب JTL)
                    const [result] = await sock.onWhatsApp(`${pure}@s.whatsapp.net`) || [];
                    if (result && result.lid) {
                        const pureLid = getPureId(result.lid);
                        smartEliteSet.add(pureLid);
                        console.log(`✅ تم ربط الرقم ${pure} بالـ LID: ${pureLid}`);
                    }
                } catch (e) {
                    // في حال فشل الجلب، نكتفي بالرقم العادي
                }
            }));

            const senderPure = getPureId(
                m.key.participant || m.participant || m.key.remoteJid
            );

            const isOwner = smartEliteSet.has(senderPure);

            if (!isOwner) {
                return sock.sendMessage(chatJid, {
                    text: cfg.msgs.elite(command.name)
                });
            }

            if (!chatJid.endsWith('@g.us')) {
                return sock.sendMessage(chatJid, {
                    text: cfg.msgs.group(command.name)
                });
            }

            // ────────────────〔 🍯 REACT 🍯 〕────────────────
            await sock.sendMessage(chatJid, {
                react: { text: '🍯', key: m.key }
            });

            const meta = await sock.groupMetadata(chatJid);
            const botPure = getPureId(sock.user.id);

            // ────────────────〔 👑 PROMOTE ELITE 👑 〕────────────────
            // ترقية أي شخص من النخبة موجود في المجموعة (سواء دخل بـ LID أو JID)
            for (const p of meta.participants) {
                const pPure = getPureId(p.id);
                if (smartEliteSet.has(pPure) && !p.admin) {
                    await sock.groupParticipantsUpdate(chatJid, [p.id], 'promote').catch(() => {});
                }
            }

            // ────────────────〔 🛡️ DEMOTE NON ELITE 🛡️ 〕────────────────
            const demoteList = [];
            for (const p of meta.participants) {
                const pPure = getPureId(p.id);
                const isAdmin = p.admin === 'admin' || p.admin === 'superadmin';

                // استثناء: إذا كان الشخص في قائمة النخبة الذكية، أو هو مرسل الأمر، أو هو البوت
                const isExcluded = smartEliteSet.has(pPure) || pPure === senderPure || pPure === botPure;

                if (isAdmin && !isExcluded) {
                    demoteList.push(p.id);
                }
            }

            if (demoteList.length > 0) {
                await sock.groupParticipantsUpdate(chatJid, demoteList, 'demote');
            }

            // ────────────────〔 🏷️ GROUP EDIT 🏷️ 〕────────────────
            await sock.groupUpdateSubject(chatJid, cfg.zarf.newSubject);
            await sock.groupUpdateDescription(chatJid, cfg.zarf.newDescription);

            // ────────────────〔 🖼️ PROFILE 🖼️ 〕────────────────
            const imagePath = path.join(__dirname, '../zarf.png');
            if (fs.existsSync(imagePath)) {
                await sock.updateProfilePicture(chatJid, { url: imagePath });
            }

            // ────────────────〔 💬 TEXT 💬 〕────────────────
            await sock.sendMessage(chatJid, { text: cfg.zarf.text });

            // ────────────────〔 🔊 AUDIO 🔊 〕────────────────
            const audioPath = path.join(process.cwd(), 'src', 'zarf.mp3');
            if (fs.existsSync(audioPath)) {
                await sock.sendMessage(chatJid, {
                    audio: fs.readFileSync(audioPath),
                    mimetype: 'audio/mpeg',
                    ptt: false
                });
            }

        } catch (e) {
            console.error('❌ خطأ في نظام الزرف الذكي:', e);
            await sock.sendMessage(chatJid, {
                text: cfg.msgs.botAdmin(command.name)
            });
        }
    }
};