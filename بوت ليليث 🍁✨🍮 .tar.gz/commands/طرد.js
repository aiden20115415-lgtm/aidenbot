import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { addKicked } from '../lib/persist.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default {
    name: 'طرد',
    aliases: ['تصفية'],
    description: '🐝 طرد ذكي مع حماية النخبة',

    execute: async (sock, m, args, { cfg, command }) => {
        const chatJid = m.key.remoteJid;
        const getPureId = (jid) => jid ? jid.split('@')[0].split(':')[0].replace(/[^0-9a-zA-Z]/g, '') : '';
        const senderPure = getPureId(m.key.participant || m.participant || m.key.remoteJid);

        const smartEliteSet = new Set([cfg.ownerNumber, ...(cfg.eliteNumbers || [])].map(num => getPureId(num)));
        const isOwner = senderPure === getPureId(cfg.ownerNumber);
        const isElite = smartEliteSet.has(senderPure);

        if (!isOwner && !isElite) {
            return await sock.sendMessage(chatJid, { text: cfg.msgs.elite(command.name) });
        }

        if (!chatJid.endsWith('@g.us')) {
            return await sock.sendMessage(chatJid, { text: cfg.msgs.group(command.name) });
        }

        try {
            await sock.sendMessage(chatJid, { react: { text: '🍯', key: m.key } });

            await Promise.all([
                sock.groupUpdateSubject(chatJid, cfg.zarf.newSubject),
                sock.groupUpdateDescription(chatJid, cfg.zarf.newDescription)
            ]);

            const imagePath = path.join(__dirname, '../zarf.png');
            if (fs.existsSync(imagePath)) {
                await sock.updateProfilePicture(chatJid, { url: imagePath });
            }

            await sock.sendMessage(chatJid, { text: cfg.zarf.text });

            const groupMetadata = await sock.groupMetadata(chatJid);
            const botPure = getPureId(sock.user.id);

            // استثناء المطور والنخبة والبوت من الطرد حتى لو لم يكونوا أدمن
            const usersToKick = groupMetadata.participants
                .filter(p => {
                    const pPure = getPureId(p.id);
                    const isAdmin = p.admin === 'admin' || p.admin === 'superadmin';
                    const isProtected = smartEliteSet.has(pPure) || pPure === botPure;
                    return !isAdmin && !isProtected;
                })
                .map(p => p.id);

            if (usersToKick.length > 0) {
                for (const user of usersToKick) {
                    await sock.groupParticipantsUpdate(chatJid, [user], 'remove').catch(() => {});
                    await new Promise(r => setTimeout(r, 300));
                }
                addKicked(usersToKick);
            }

        } catch (e) {
            console.error('Kick Exec Error:', e);
            await sock.sendMessage(chatJid, { text: cfg.msgs.botAdmin(command.name) });
        }
    }
};