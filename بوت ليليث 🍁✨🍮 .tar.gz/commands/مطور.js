export default {
    name: 'مطور',
    aliases: ['المطور', 'owner', 'مطوري'],
    description: '🐝 عرض معلومات مطور البوت كجهة اتصال',

    execute: async (sock, m, args, { cfg }) => {

        try {

            // ────────────────〔 🐝 REACTION 🐝 〕────────────────
            await sock.sendMessage(
                m.key.remoteJid,
                {
                    react: {
                        text: '🐝',
                        key: m.key
                    }
                }
            );

            const ownerJid = cfg.ownerNumber;

            const ownerName =
                cfg.ownerName || '𝐍𝐚𝐦𝐞 : 𝐋𝐢𝐥𝐢𝐭𝐡 ꙮ';

            const phoneNumber =
                ownerJid.split('@')[0];

            // ────────────────〔 📇 VCARD CONTACT 📇 〕────────────────
            const vcard =
`BEGIN:VCARD
VERSION:3.0
FN:${ownerName}
TEL;type=CELL;type=VOICE;waid=${phoneNumber}:+${phoneNumber}
END:VCARD`;

            // ────────────────〔 📩 SEND CONTACT 📩 〕────────────────
            await sock.sendMessage(
                m.key.remoteJid,
                {
                    contacts: {
                        displayName: ownerName,
                        contacts: [
                            {
                                vcard
                            }
                        ]
                    }
                },
                { quoted: m }
            );

        } catch (e) {

            console.error(
                'Owner Contact Error:',
                e
            );

            await sock.sendMessage(
                m.key.remoteJid,
                {
                    text:
`❌ حدث خطأ أثناء إرسال جهة المطور`
                },
                { quoted: m }
            );
        }
    }
};