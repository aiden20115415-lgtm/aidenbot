export default {
    name: 'منشن',
    aliases: ['الكل', 'tagall'],
    description: '🐝 منشن جميع أعضاء المجموعة',
    execute: async (sock, m, args, { cfg, command }) => {
        try {
            const chatJid = m.key.remoteJid;
            const getPureId = (jid) => jid ? jid.split('@')[0].split(':')[0].replace(/[^0-9a-zA-Z]/g, '') : '';
            
            const senderPure = getPureId(m.key.participant || m.participant || m.key.remoteJid);

            if (!chatJid.endsWith('@g.us')) {
                return await sock.sendMessage(chatJid, { text: cfg.msgs.group(command.name) }, { quoted: m });
            }

            const groupMetadata = await sock.groupMetadata(chatJid);
            const participants = groupMetadata.participants;
            const admins = participants.filter(p => p.admin).map(p => getPureId(p.id));

            // التحقق الذكي من الصلاحيات
            const smartEliteSet = new Set([cfg.ownerNumber, ...(cfg.eliteNumbers || [])].map(num => getPureId(num)));
            const isOwner = senderPure === getPureId(cfg.ownerNumber);
            const isElite = smartEliteSet.has(senderPure);
            const isAdmin = admins.includes(senderPure);

            if (!isOwner && !isElite && !isAdmin) {
                return await sock.sendMessage(chatJid, { text: cfg.msgs.admin(command.name) }, { quoted: m });
            }

            await sock.sendMessage(chatJid, { react: { text: '🐝', key: m.key } });

            let message = args.length > 0
                ? `╭━━━〔 🐝 LILITH TAG 🐝 〕━━━╮\n┃ 💌 ${args.join(' ')}\n╰━━━━━━━━━━━━━━━━━━━━╯\n\n`
                : `╭━━━〔 🐝 LILITH TAG 🐝 〕━━━╮\n┃ 📢 نداء للجميع\n╰━━━━━━━━━━━━━━━━━━━━╯\n\n`;

            const mentions = [];
            participants.forEach((mem, i) => {
                message += `┃ ${i + 1} ➜ @${mem.id.split('@')[0]}\n`;
                mentions.push(mem.id);
            });
            message += `\n╰━━━〔 🍯 LILITH BOT 🐝 〕━━━╯`;

            await sock.sendMessage(chatJid, { text: message, mentions: mentions }, { quoted: m });

        } catch (e) {
            console.error('Mention Error:', e);
            await sock.sendMessage(m.key.remoteJid, { text: `╭━━━〔 ❌ LILITH ERROR ❌ 〕━━━╮\n┃ ⚠️ Failed To Execute Tagall\n╰━━━━━━━━━━━━━━━━━━━━╯` }, { quoted: m });
        }
    }
};