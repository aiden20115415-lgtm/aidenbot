import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(
    fileURLToPath(import.meta.url)
);

const configPath = path.join(
    __dirname,
    '../config.js'
);

export default {

    name: 'نخبة',
    aliases: ['elite'],
    description: '🐝 إدارة أعضاء النخبة بنظام ذكي',

    execute: async (sock, m, args, { cfg }) => {

        const chatJid = m.key.remoteJid;

        // دالة التنقية الموحدة (نفس نظام الزرف)
        const getPureId = (jid) => {
            if (!jid) return '';
            return jid.split('@')[0].split(':')[0].replace(/[^0-9a-zA-Z]/g, '');
        };

        const senderPure = getPureId(
            m.key.participant || m.participant || m.key.remoteJid
        );

        // بناء قائمة النخبة الذكية للفحص
        const smartEliteSet = new Set();
        const rawElite = [cfg.ownerNumber, ...(cfg.eliteNumbers || [])];
        
        await Promise.all(rawElite.map(async (num) => {
            const pure = getPureId(num);
            if (pure) smartEliteSet.add(pure);
        }));

        const isOwner = senderPure === getPureId(cfg.ownerNumber);
        const isElite = smartEliteSet.has(senderPure);

        if (!isOwner && !isElite) {
            return await sock.sendMessage(chatJid, {
                text: `╭━━━〔 🐝 ELITE ONLY 🐝 〕━━━╮\n┃ ⚠️ Access Denied\n┃ 🍯 Elite Members Only\n╰━━━━━━━━━━━━━━━━━━━━╯`
            }, { quoted: m });
        }

        const action = args[0];
        let target = null;

        // تحديد المستهدف (من الرد أو الرقم)
        if (m.message?.extendedTextMessage?.contextInfo?.participant) {
            target = m.message.extendedTextMessage.contextInfo.participant;
        } else if (args[1]) {
            target = args[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        }

        try {
            let configContent = fs.readFileSync(configPath, 'utf8');

            if (action === 'اضف') {
                if (!target) {
                    return sock.sendMessage(chatJid, {
                        text: `╭━━━〔 ⚠️ LILITH NOTICE ⚠️ 〕━━━╮\n┃ 📥 Reply Or Enter Number\n╰━━━━━━━━━━━━━━━━━━━━╯`
                    }, { quoted: m });
                }

                // الذكاء: جلب الـ LID و الـ JID للهدف قبل الإضافة
                const [result] = await sock.onWhatsApp(target) || [];
                const targetJid = result?.jid || target;
                const targetLid = result?.lid || null;

                // التحقق إذا كان موجوداً مسبقاً بأي صيغة
                if (cfg.eliteNumbers.includes(targetJid) || (targetLid && cfg.eliteNumbers.includes(targetLid))) {
                    return sock.sendMessage(chatJid, {
                        text: `╭━━━〔 🐝 ELITE SYSTEM 🐝 〕━━━╮\n┃ 🍯 Already In Elite List\n╰━━━━━━━━━━━━━━━━━━━━╯`
                    }, { quoted: m });
                }

                // إضافة الـ JID والـ LID (إذا وجد) لضمان الدقة
                cfg.eliteNumbers.push(targetJid);
                if (targetLid) cfg.eliteNumbers.push(targetLid);

                const updatedList = JSON.stringify(cfg.eliteNumbers, null, 4);
                configContent = configContent.replace(/eliteNumbers:\s*\[[\s\S]*?\]/, `eliteNumbers: ${updatedList}`);
                fs.writeFileSync(configPath, configContent, 'utf8');

                await sock.sendMessage(chatJid, { react: { text: '🐝', key: m.key } });
                await sock.sendMessage(chatJid, {
                    text: `╭━━━〔 🐝 ELITE ADDED 🐝 〕━━━╮\n┃ 🍯 Welcome To Elite\n┃ 👤 @${targetJid.split('@')[0]}\n╰━━━━━━━━━━━━━━━━━━━━╯`,
                    mentions: [targetJid]
                }, { quoted: m });

            } else if (action === 'ازل') {
                if (!target) {
                    return sock.sendMessage(chatJid, {
                        text: `╭━━━〔 ⚠️ LILITH NOTICE ⚠️ 〕━━━╮\n┃ 📥 Reply Or Enter Number\n╰━━━━━━━━━━━━━━━━━━━━╯`
                    }, { quoted: m });
                }

                const pureTarget = getPureId(target);
                if (pureTarget === getPureId(cfg.ownerNumber)) {
                    return sock.sendMessage(chatJid, {
                        text: `╭━━━〔 ❌ OWNER PROTECTED ❌ 〕━━━╮\n┃ 👑 Main Developer Protected\n╰━━━━━━━━━━━━━━━━━━━━━━╯`
                    }, { quoted: m });
                }

                // إزالة كافة الصيغ المرتبطة بالرقم (JID و LID)
                cfg.eliteNumbers = cfg.eliteNumbers.filter(num => getPureId(num) !== pureTarget);

                const updatedList = JSON.stringify(cfg.eliteNumbers, null, 4);
                configContent = configContent.replace(/eliteNumbers:\s*\[[\s\S]*?\]/, `eliteNumbers: ${updatedList}`);
                fs.writeFileSync(configPath, configContent, 'utf8');

                await sock.sendMessage(chatJid, { react: { text: '🍯', key: m.key } });
                await sock.sendMessage(chatJid, {
                    text: `╭━━━〔 🐝 ELITE REMOVED 🐝 〕━━━╮\n┃ ❌ Removed From Elite\n┃ 👤 @${target.split('@')[0]}\n╰━━━━━━━━━━━━━━━━━━━━╯`,
                    mentions: [target]
                }, { quoted: m });

            } else if (action === 'عرض') {
                if (cfg.eliteNumbers.length === 0) {
                    return sock.sendMessage(chatJid, {
                        text: `╭━━━〔 🐝 ELITE LIST 🐝 〕━━━╮\n┃ 🍯 Elite List Empty\n╰━━━━━━━━━━━━━━━━━━━━╯`
                    }, { quoted: m });
                }

                // عرض الأرقام الفريدة فقط (تصفية JID/LID المكرر في العرض)
                const uniqueNumbers = [...new Set(cfg.eliteNumbers.map(num => num.split('@')[0]))];
                let listMsg = `╭━━━〔 🐝 ELITE MEMBERS 🐝 〕━━━╮\n`;
                uniqueNumbers.forEach((num, i) => {
                    listMsg += `┃ ${i + 1} ➜ @${num}\n`;
                });
                listMsg += `╰━━━━━━━━━━━━━━━━━━━━╯`;

                await sock.sendMessage(chatJid, {
                    text: listMsg,
                    mentions: cfg.eliteNumbers
                }, { quoted: m });

            } else {
                const usage = `╭━━━〔 🐝 ELITE HELP 🐝 〕━━━╮\n\n┃ ➕ .نخبة اضف\n┃ ❌ .نخبة ازل\n┃ 📜 .نخبة عرض\n\n╰━━━━━━━━━━━━━━━━━━━━╯`;
                await sock.sendMessage(chatJid, { text: usage }, { quoted: m });
            }

        } catch (error) {
            console.error('Elite Error:', error);
            await sock.sendMessage(chatJid, {
                text: `╭━━━〔 ❌ LILITH ERROR ❌ 〕━━━╮\n┃ ⚠️ Failed To Edit Elite\n╰━━━━━━━━━━━━━━━━━━━━╯`
            }, { quoted: m });
        }
    }
};