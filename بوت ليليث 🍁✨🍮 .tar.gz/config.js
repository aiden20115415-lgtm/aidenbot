export default {

    // ────────────────〔 🐝 DEVELOPER 🐝 〕────────────────
    ownerName: '🐝 LILIY',
    
    ownerNumber: '212705655633@s.whatsapp.net',

    eliteNumbers: [
    "212705655633@s.whatsapp.net",
    "212603620687@s.whatsapp.net",
    "212769742100@s.whatsapp.net",
    "212764716690@s.whatsapp.net",
    "972533933401@s.whatsapp.net",
    "972533927544@s.whatsapp.net",
    "972533930834@s.whatsapp.net",
    "972504379312@s.whatsapp.net",
    "212764716693@s.whatsapp.net",
    "972504383893@s.whatsapp.net",
    "972509540811@s.whatsapp.net",
    "84922610392@s.whatsapp.net",
    "212780265225@s.whatsapp.net",
    "84586992058@s.whatsapp.net",
    "174543863869517@s.whatsapp.net",
    "174543863869517@lid"
],

    // ────────────────〔 🍯 BOT INFO 🍯 〕────────────────
    botName: '🐝 LILITH-BOT',

    prefix: '.',

    mode: 'Public',

    botVersion: '2.0.0',

    sessionPath: './session',

    botNumber: '84586992058@s.whatsapp.net',

    // ────────────────〔 🌙 ZARF SYSTEM 🌙 〕────────────────
    zarf: {

        newSubject: `🐝⃝𝐋𝐈𝐋𝐈𝐓𝐇 ꒰🍯⃝꒱مـزروف`,

        newDescription:
`╭━━━〔 🐝 𝐋𝐈𝐋𝐈𝐓𝐇 🐝 〕━━━╮
┃
┃ 🍯 Group Controlled
┃ ⚡ Powered By LILIY
┃ 🌙 LILITH SYSTEM ACTIVE
┃
╰━━━〔 🍯🐝🍯 〕━━━╯`,

        text:
`╭━━━〔 🐝 𝐋𝐈𝐋𝐈𝐓𝐇 🐝 〕━━━╮

┃ 🍯 Group Successfully Taken
┃ ⚡ Controlled By LILIY
┃ 🌙 Sweet Like Honey

┃ 🐝 L I L I T H - B O T 🐝

╰━━━〔 🍯 HONEY POWER 🍯 〕━━━╯`
    },

    // ────────────────〔 👑 RIGHTS 👑 〕────────────────
    botLogo: 'LILITH',

    botRights: '🐝 𝐋𝐈𝐋𝐈𝐘 - 𝐋𝐈𝐋𝐈𝐓𝐇 𝐁𝐎𝐓 🍯',

    // ────────────────〔 ⚡ SYSTEM MESSAGES ⚡ 〕────────────────
    msgs: {

        owner: (comando) =>
`╭━━━〔 🐝 OWNER ONLY 🐝 〕━━━╮
┃ ⚠️ Access Denied
┃ 👑 Developer Command
┃ 📥 Used : ${comando}
╰━━━━━━━━━━━━━━━━━━━━╯`,

        elite: (comando) =>
`╭━━━〔 🐝 ELITE ONLY 🐝 〕━━━╮
┃ ⚠️ Access Denied
┃ 🍯 Elite Members Only
┃ 📥 Used : ${comando}
╰━━━━━━━━━━━━━━━━━━━━╯`,

        group: (comando) =>
`╭━━━〔 🐝 GROUP ONLY 🐝 〕━━━╮
┃ ⚠️ Invalid Place
┃ 👥 Groups Only
┃ 📥 Used : ${comando}
╰━━━━━━━━━━━━━━━━━━━━╯`,

        botAdmin: (comando) =>
`╭━━━〔 🐝 BOT ADMIN 🐝 〕━━━╮
┃ ⚠️ Permission Missing
┃ 👑 Bot Must Be Admin
┃ 📥 Used : ${comando}
╰━━━━━━━━━━━━━━━━━━━━╯`,

        admin: (comando) =>
`╭━━━〔 🐝 ADMIN ONLY 🐝 〕━━━╮
┃ ⚠️ Access Denied
┃ 👑 Admins Only
┃ 📥 Used : ${comando}
╰━━━━━━━━━━━━━━━━━━━━╯`,

        private: (comando) =>
`╭━━━〔 🐝 PRIVATE MODE 🐝 〕━━━╮
┃ ⚠️ Bot In Private Mode
┃ 🍯 Developers Only
┃ 📥 Used : ${comando}
╰━━━━━━━━━━━━━━━━━━━━╯`
    },

};

// ────────────────〔 🐝 LILIY BOT 🐝 〕────────────────