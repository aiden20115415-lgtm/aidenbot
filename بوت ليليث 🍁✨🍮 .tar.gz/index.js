// ────────────────〔 🐝 LILITH CORE 🐝 〕────────────────
import Auth, {
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore
} from '@whiskeysockets/baileys';

import cfonts from 'cfonts';
const { say } = cfonts;

import chalk from 'chalk';
import pino from 'pino';
import fs from 'fs';
import boxen from 'boxen';
import path from 'path';
import { fileURLToPath } from 'url';
import readline from 'readline';

// ────────────────〔 🍯 SYSTEMS 🍯 〕────────────────
import cfg from './config.js';
import main from './main.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ────────────────〔 📥 PAIRING INPUT 📥 〕────────────────
const question = (text) => {

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    return new Promise((resolve) =>
        rl.question(text, (ans) => {
            rl.close();
            resolve(ans);
        })
    );
};

// ────────────────〔 🐝 LILITH LOGO 🐝 〕────────────────
say(cfg.botLogo || 'LILITH', {
    font: 'block',
    align: 'center',
    colors: ['#FFD54F', '#F4B400'],
    background: 'transparent',
    letterSpacing: 1,
    lineHeight: 1,
    space: true,
    maxLength: '0',
});

console.log(
chalk.hex('#FFD54F')(
`╭━━━〔 🐝 LILITH SYSTEM 🐝 〕━━━╮
┃ 🍯 Developer : LILIY
┃ ⚡ Version   : 2.0
┃ 🌙 Status    : Initializing...
╰━━━━━━━━━━━━━━━━━━━━━━╯\n`
)
);

// ────────────────〔 ⚡ START BOT ⚡ 〕────────────────
async function Go() {

    const { state, saveCreds } =
        await useMultiFileAuthState(cfg.sessionPath);

    const { version } =
        await fetchLatestBaileysVersion();

    const sock = Auth.default({

        version,

        auth: {
            creds: state.creds,

            keys: makeCacheableSignalKeyStore(
                state.keys,
                pino({ level: 'silent' })
            ),
        },

        printQRInTerminal: false,

        logger: pino({ level: 'silent' }),

        syncFullHistory: false,
    });

    // ────────────────〔 📲 PAIRING CODE 📲 〕────────────────
    if (!sock.authState.creds.registered) {

        const phoneNumber = await question(
            chalk.hex('#FFD54F')(
`\n╭━━━〔 🐝 LILITH LOGIN 🐝 〕━━━╮
┃ 📞 Enter Your Number :
╰━━━━━━━━━━━━━━━━━━━━━━╯
➤ `
            )
        );


        const code =
            await sock.requestPairingCode(phoneNumber.trim(), "LILIYBOT");

        console.log(
            boxen(
                chalk.hex('#FFD54F')(
`🐝 LILITH PAIRING CODE 🐝

🍯 CODE : ${code}

⚡ Enter this code in WhatsApp`
                ),
                {
                    padding: 1,
                    margin: 1,
                    borderStyle: 'round',
                    borderColor: 'yellow',
                    backgroundColor: '#111111'
                }
            )
        );
    }

    // ────────────────〔 💾 SAVE SESSION 💾 〕────────────────
    sock.ev.on('creds.update', saveCreds);

    // ────────────────〔 📩 MESSAGE SYSTEM 📩 〕────────────────
    sock.ev.on('messages.upsert', (data) => {
        main.handler(sock, data, { cfg });
    });

    // ────────────────〔 👥 GROUP EVENTS 👥 〕────────────────
    sock.ev.on('group-participants.update', (data) => {
        main.handler(
            sock,
            { ...data, isGroupUpdate: true },
            { cfg }
        );
    });

    // ────────────────〔 ⚙️ GROUP SETTINGS ⚙️ 〕────────────────
    sock.ev.on('groups.update', ([data]) => {
        main.handler(
            sock,
            { ...data, isGroupUpdate: true },
            { cfg }
        );
    });

    // ────────────────〔 🌙 CONNECTION STATUS 🌙 〕────────────────
    sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {

        if (connection === 'close') {

            const again =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;

            if (again) {

                console.log(
chalk.yellowBright(
`\n╭━━━〔 ⚠️ LILITH WARNING ⚠️ 〕━━━╮
┃ 📡 Connection Lost
┃ 🔄 Reconnecting...
╰━━━━━━━━━━━━━━━━━━━━━━╯\n`
)
                );

                Go();

            } else {

                console.log(
chalk.redBright(
`\n╭━━━〔 ❌ LILITH SESSION ❌ 〕━━━╮
┃ ⚠️ Session Expired
┃ 📥 Login Again
╰━━━━━━━━━━━━━━━━━━━━━━╯\n`
)
                );
            }

        } else if (connection === 'open') {

            const isPublic =
                cfg.mode?.toLowerCase() === 'public';

            const modeText =
                isPublic ? 'PUBLIC' : 'PRIVATE';

            console.log(
chalk.hex('#FFD54F')(
`\n╭━━━〔 🐝 LILITH ONLINE 🐝 〕━━━╮
┃ 🌐 Status : ONLINE
┃ ⚡ Mode   : ${modeText}
┃ 🍯 Prefix : ${cfg.prefix}
┃ 👑 Owner  : LILIY
╰━━━━━━━━━━━━━━━━━━━━━━╯\n`
)
            );
        }
    });
}

// ────────────────〔 🚀 RUN BOT 🚀 〕────────────────
Go().catch(e =>
    console.error(
        chalk.redBright(
`\n╭━━━〔 ❌ FATAL ERROR ❌ 〕━━━╮
┃ ⚠️ ${e.message}
╰━━━━━━━━━━━━━━━━━━━━━━╯`
        )
    )
);

// ────────────────〔 🐝 LILIY BOT 🐝 〕────────────────