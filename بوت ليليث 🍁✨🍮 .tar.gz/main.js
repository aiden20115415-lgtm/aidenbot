// ────────────────〔 🐝 𝐋𝐈𝐋𝐈𝐓𝐇 𝐂𝐎𝐑𝐄 🐝 〕────────────────
import pino from 'pino';
import chalk from 'chalk';
import moment from 'moment-timezone';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import chokidar from 'chokidar';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export const commandsCache = { cmds: new Map(), als: new Map() };
export const systems = new Map();

// ────────────────〔 🍯 AUTO LOADER 🍯 〕────────────────
const loadFiles = async (folder, map, label, silent = false) => {
    const dir = path.join(__dirname, folder);

    if (!fs.existsSync(dir)) return;

    map.clear();

    const files = fs.readdirSync(dir).filter(f => f.endsWith('.js'));

    for (const f of files) {
        try {
            const url = `file://${path.join(dir, f)}?upd=${Date.now()}`;
            const { default: content } = await import(url);

            if (folder === 'commands' && content?.name) {

                commandsCache.cmds.set(content.name, content);

                content.aliases?.forEach(a => 
                    commandsCache.als.set(a, content.name)
                );

            } else if (folder === 'lib' && typeof content === 'function') {

                map.set(f, content);

            }

        } catch (e) {
            console.log(
                chalk.hex('#F4B400')(
`╭━━━〔 🐝 LILITH ERROR 🐝 〕━━━╮
┃ 📂 File : ${f}
┃ ⚠️ ${e.message}
╰━━━━━━━━━━━━━━━━━━╯`
                )
            );
        }
    }
};

// ────────────────〔 🔄 RELOAD SYSTEM 🔄 〕────────────────
const reloadAll = async (silent = false) => {

    await loadFiles('commands', commandsCache.cmds, 'Commands');

    await loadFiles('lib', systems, 'Systems');

    if (!silent) {

        console.log(
            chalk.hex('#FFD54F')(
`\n╭━━━〔 🐝 LILITH SYNC 🐝 〕━━━╮
┃ 🍯 Commands Updated
┃ ⚡ Systems Reloaded
┃ 🌙 Synchronization Complete
╰━━━━━━━━━━━━━━━━━━━━╯\n`
            )
        );
    }
};

chokidar.watch(
[
    path.join(__dirname, 'commands'),
    path.join(__dirname, 'lib')
],
{
    ignoreInitial: true
}).on('all', () => {
    setTimeout(() => reloadAll(false), 100);
});

await reloadAll(true);

// ────────────────〔 🌙 PRE SYSTEM 🌙 〕────────────────
export const pre = [

    async (m, { cfg }) => {

        try {

            if (m.isGroupUpdate || m.messageStubType) return true;

            const text =
                m.message?.conversation ||
                m.message?.extendedTextMessage?.text ||
                '';

            if (!text || typeof text !== 'string') return true;

            const prefix = cfg.prefix || '.';

            const isCommand = text.startsWith(prefix);

            if (isCommand) {

                const jid = m.key?.remoteJid || 'unknown';

                const senderName = m.pushName || 'Unknown';

                const time = moment()
                    .tz('Africa/Ndjamena')
                    .format('YYYY-MM-DD HH:mm:ss');

                console.log(
chalk.hex('#FFD54F')(
`\n╭━━━〔 🐝 LILITH LOG 🐝 〕━━━╮
┃ 📥 Command Detected
┃ 👤 User : ${senderName}
┃ 📡 Chat : ${jid}
┃ ⏰ Time : ${time}
┃ 💬 Text : ${text}
╰━━━━━━━━━━━━━━━━━━━━╯\n`
)
                );
            }

            return true;

        } catch (err) {

            console.log(
                chalk.red(
`╭━━━〔 ❌ PRE ERROR ❌ 〕━━━╮
┃ ${err.message}
╰━━━━━━━━━━━━━━━━━━╯`
                )
            );

            return true;
        }
    }
];

// ────────────────〔 ⚡ MAIN HANDLER ⚡ 〕────────────────
export const handler = async (sock, data, { cfg }) => {

    try {

        let m;

        if (data.isGroupUpdate) {
            m = data;
        } else {
            m = data.messages && data.messages[0];
        }

        if (!m || !m.key) return;

        const isStub = !!m?.messageStubType;

        const isGroupUpdate = !!m?.isGroupUpdate;

        if (!m.message && !isGroupUpdate && !isStub) return;

        if (m.key.fromMe) return;

        const senderJid =
            m.key?.participant ||
            m.participant ||
            m.key?.remoteJid;

        if (!senderJid) return;

        // ────────────────〔 🛡️ PRIVATE MODE 🛡️ 〕────────────────
        const isOwner = cfg.ownerNumber === senderJid;

        const isElite = cfg.eliteNumbers?.includes(senderJid);

        const isPrivate =
            cfg.mode?.toLowerCase() === 'private' ||
            cfg.mode?.toLowerCase() === 'self';

        if (isPrivate && !isOwner && !isElite) return;

        const ctx = {
            sock,
            cfg,
            cmds: commandsCache.cmds,
            als: commandsCache.als,
            systems
        };

        for (const [name, sys] of systems) {

            const result = await sys(sock, m, ctx)
                .catch(console.error);

            if (result === true) return;
        }

        if (m.isGroupUpdate || isStub) return;

        // ────────────────〔 🍯 COMMAND SYSTEM 🍯 〕────────────────
        const txt =
            m.message.conversation ||
            m.message.extendedTextMessage?.text ||
            '';

        const prefix = cfg.prefix || '.';

        if (!txt.startsWith(prefix)) return;

        const args = txt
            .slice(prefix.length)
            .trim()
            .split(/\s+/);

        const cmdName = args.shift().toLowerCase();

        const key = commandsCache.cmds.has(cmdName)
            ? cmdName
            : commandsCache.als.get(cmdName);

        if (key) {

            const command = commandsCache.cmds.get(key);

            for (const fn of pre) {

                if (!(await fn(m, ctx))) return;
            }

            await command.execute(
                sock,
                m,
                args,
                {
                    ...ctx,
                    command
                }
            );
        }

    } catch (e) {

        console.log(
chalk.red(
`╭━━━〔 ❌ LILITH ERROR ❌ 〕━━━╮
┃ ⚠️ ${e.message}
╰━━━━━━━━━━━━━━━━━━━━╯`
)
        );
    }
};

export default { handler };

// ────────────────〔 🐝 𝐋𝐈𝐋𝐈𝐘 𝐁𝐎𝐓 🐝 〕────────────────